/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginuser;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginuserTest {
    
    public LoginuserTest() {
    }

    /**
     * Test of checkUserName method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testCheckUserName_String() {
        System.out.println("checkUserName");
        String username = "";
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.checkUserName(username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkUserName method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testCheckUserName_0args() {
        System.out.println("checkUserName");
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.checkUserName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testCheckPasswordComplexity_String() {
        System.out.println("checkPasswordComplexity");
        String password = "";
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testCheckPasswordComplexity_0args() {
        System.out.println("checkPasswordComplexity");
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.checkPasswordComplexity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkCellPhoneNumber method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testCheckCellPhoneNumber_String() {
        System.out.println("checkCellPhoneNumber");
        String phone = "";
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.checkCellPhoneNumber(phone);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkCellPhoneNumber method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testCheckCellPhoneNumber_0args() {
        System.out.println("checkCellPhoneNumber");
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.checkCellPhoneNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testRegisterUser_3args() {
        System.out.println("registerUser");
        String user = "";
        String pass = "";
        String ph = "";
        Loginuser instance = new Loginuser();
        String expResult = "";
        String result = instance.registerUser(user, pass, ph);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testRegisterUser_0args() {
        System.out.println("registerUser");
        Loginuser instance = new Loginuser();
        String expResult = "";
        String result = instance.registerUser();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String enteredUser = "";
        String enteredPass = "";
        Loginuser instance = new Loginuser();
        boolean expResult = false;
        boolean result = instance.loginUser(enteredUser, enteredPass);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Loginuser.
     */
    @org.junit.jupiter.api.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Loginuser.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
