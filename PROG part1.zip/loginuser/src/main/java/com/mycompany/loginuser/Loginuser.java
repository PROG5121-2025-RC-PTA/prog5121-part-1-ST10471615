/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginuser;

/**
 *
 * @author Student
 */

import java.util.Scanner;

public class Loginuser {
    private String username;
    private String password;
    private String phone;

    // Default constructor for main method usage
    public Loginuser() {}

    // Constructor used by LoginTest
    public Loginuser(String username, String password, String phone, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.phone = phone;
    }

    // --- LOGIC METHODS ---
    public boolean checkUserName(String username) {
        return (username != null && username.contains("_") && username.length() <= 5);
    }
    
    public boolean checkUserName() {
        return checkUserName(this.username);
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        // Regex: 8+ chars, 1 digit, 1 lowercase, 1 uppercase, 1 special char
        String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$";
        return password.matches(regex);
    }
    
    public boolean checkPasswordComplexity() {
        return checkPasswordComplexity(this.password);
    }

    public boolean checkCellPhoneNumber(String phone) {
        // Checks length 12, starts with +27, and 4th digit is between 6-8
        if (phone == null || phone.length() != 12) return false;
        String saCode = "+27";
        int fourthDigit = Character.getNumericValue(phone.charAt(3));
        return phone.startsWith(saCode) && (fourthDigit >= 6 && fourthDigit <= 8);
    }
    
    public boolean checkCellPhoneNumber() {
        return checkCellPhoneNumber(this.phone);
    }

    public String registerUser(String user, String pass, String ph) {
        if (!checkUserName(user)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(pass)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(ph)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        this.username = user;
        this.password = pass;
        this.phone = ph;
        return "Username successfully captured. Password successfully captured. Cell phone number successfully added.";
    }
    
    public String registerUser() {
        return registerUser(this.username, this.password, this.phone);
    }

    public boolean loginUser(String enteredUser, String enteredPass) {
        return (this.username != null && this.username.equals(enteredUser)) && 
               (this.password != null && this.password.equals(enteredPass));
    }

    // --- MAIN METHOD ---
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // FIX: You must instantiate the class to use non-static methods
        Loginuser app = new Loginuser();

        System.out.println("--- USER REGISTRATION ---");
        System.out.print("Enter Username: ");
        String user = input.nextLine();
        System.out.print("Enter Password: ");
        String pass = input.nextLine();
        System.out.print("Enter Phone (+27...): ");
        String phone = input.nextLine();

        // Now 'app' is recognized
        String status = app.registerUser(user, pass, phone);
        System.out.println("\n" + status);

        // Only proceed to login if registration was successful
        if (status.startsWith("Username successfully captured")) {
            System.out.println("\n----- USER LOGIN -----");
            System.out.print("Enter Username: ");
            String lUser = input.nextLine();
            System.out.print("Enter Password: ");
            String lPass = input.nextLine();

            if (app.loginUser(lUser, lPass)) {
                System.out.println("Login Successful! Welcome back.");
            } else {
                System.out.println("Login Failed. Incorrect username or password.");
            }
        }
        input.close();
    }
}

